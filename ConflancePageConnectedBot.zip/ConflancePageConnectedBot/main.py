import streamlit as st
from streamlit import success
from sympy.plotting.textplot import is_valid

from rag_pipeline import RagPipeline
from validator import AnswerValidator
from confluence_service import ConfluenceService
from langchain_community.llms import Ollama
from config import *

st.set_page_config(page_title="Confluence Page Connected Bot")
st.title("Confluence Page Connected Bot")

try:
    test_llm =Ollama(model=LLM_MODEL)
    test_llm.invoke("ping")
    st.success("LLM connected ")
except:
    st.error("LLM not connected")

conf = ConfluenceService()
if conf.check_connection():
    st.success("confluence connected")
else:
    st.error("confluence not connected")

st.divider()

pipeline =RagPipeline()
validator = AnswerValidator()

question = st.text_input("Question")

if st.button("Answer"):
    if question:
        with st.spinner("processing..."):
            answer, context = pipeline.generate_answers(question)
            is_valid = validator.validate(question, answer, context)

        if is_valid:
            st.subheader("Answer")
            st.write(answer)
        else:
            st.warning("please refine your question")