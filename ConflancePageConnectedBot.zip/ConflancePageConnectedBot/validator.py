
from langchain_community.llms import Ollama
from config import *

class AnswerValidator:
    def __init__(self):
        self.llm = Ollama(model=LLM_MODEL)

    def validate(self, question, answer, context):
        prompt= f"""check if the answer is strictly by context. 
        context: {context}
        question: {question}
        answer: {answer}
        reply only valid or invalid

            """
        result =self.llm.invoke(prompt)
        return "valid" in result