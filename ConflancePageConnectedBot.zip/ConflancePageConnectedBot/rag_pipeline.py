
from langchain_community.llms import Ollama


from config import *
from confluence_service import ConfluenceService
from vector_store import VectorStoreManager

class RagPipeline:

    def __init__(self):
        self.llm=Ollama(model= LLM_MODEL)
        self.confluence=ConfluenceService()
        self.vector_store=VectorStoreManager()

    def classify_intent(self,question):
        q = question.lower()
        if "api" in q:
            return "api"
        if "flow" in q:
            return "flow"
        if "hld" in q:
            return "hld"
        if "lld" in q:
            return "lld"
        return "general"

    def fetch_and_index(self, query):
        results = self.confluence.search_pages(query)

        if not results.get("results"):
            return "no data found"

        for page in results["results"]:
            page_id = page["id"]
            page_data = self.confluence.get_page_content(page_id)
            self.vector_store.index_page(page_data)


    def generate_answers(self, question):
        intent = self.classify_intent(question)
        docs = self.vector_store.similarity_search(question)

        if len(docs)< MIN_RESULTS_THRESHOLD:
            self.fetch_and_index(question)
            docs = self.vector_store.similarity_search(question)

        if not docs:
            return "no data found"

        context = "\n\n".join([d.pages_content["text"] for d in docs])

        prompt=f""" 
you are system dosumentation assistant.
intent:{intent}
use only the provided context
context:{context}
question:{question}

provide structured and clear answer
"""
        answer = self.llm.invoke(prompt)
        return answer , context