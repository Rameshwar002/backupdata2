import requests
from bs4 import BeautifulSoup
from config import *

class ConfluenceService:

    def __init__(self):
        self.auth = (CONFLUENCE_EMAIL, CONFLUENCE_API_TOKEN)

    def check_connection(self):
        try:
            r = requests.get(
                f"{CONFLUENCE_BASE_URL}/rest/api/space",
                    auth=self.auth
            )
            return r.status_code == 200
        except:
            return False

    def search_pages(self, query):
        url = f"{CONFLUENCE_BASE_URL}/rest/api/space/search"
        params = {
            "cql": f'text "{query}" AND space= "{SPACE_KEY}" ',
            "expand" : "version"
        }
        response = requests.get(url, auth=self.auth, params=params)
        return response.json()

    def get_page_content(self, page_id):
        url = f"{CONFLUENCE_BASE_URL}/rest/api/space/{page_id}"
        params = {"expand": "body.storage, version"}
        response = requests.get(url, auth=self.auth, params=params)
        data = response.json()
        html= data["body"]["storage"]["value"]
        soup = BeautifulSoup(html, "html.parser")
        text = soup.get_text(separator="\n")

        return {
            "page_id": page_id,
            "text": data["title"],
            "html": text,
            "version": data["version"]["number"]
        }

