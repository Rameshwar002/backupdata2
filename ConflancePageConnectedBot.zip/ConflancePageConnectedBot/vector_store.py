from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from config import *

class VectorStoreManager:

    def __init__(self):
        self.embeddings = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL)

        self.vectordb = Chroma(
            persist_directory= VECTOR_DB_DIR,
            embedding_function=self.embeddings
        )

    def similarity_search(self, query):
        return self.vectordb.similarity_search(query, k=TOP_K_RESULTS)

    def index_page(self,page_data):
        existing = self.vectordb.get(where={"page_id":page_data["page_id"]})

        if existing["metadatas"]:
            stored_version = existing["metadatas"][0]["version"]
            if stored_version == page_data["version"]:
                return
            else:
                self.vectordb.delete(where={"page_id":page_data["page_id"]})

            splitter = RecursiveCharacterTextSplitter(
                chunk_size= 800,
                chunk_overlap= 100
            )

            chunks =splitter.split_text(page_data["text"])

            metadata =[{
                "page_id":page_data["page_id"],
                "title":page_data["title"],
                "version":page_data["version"],
                "location":f"{page_data["location"]} (Confluence)"
            } for _ in chunks]

            self.vectordb.add_texts(chunks,metadatas=metadata)
            self.vectordb.persist()