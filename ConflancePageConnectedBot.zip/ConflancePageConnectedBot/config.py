

CONFLUENCE_BASE_URL = 'https://your-company.atlassion.net/wiki'
CONFLUENCE_EMAIL = " NA"
CONFLUENCE_API_TOKEN = " NA"

SPACE_KEY = " "

VECTOR_DB_DIR = "./chroma_db"

LLM_MODEL= "llama3.2"
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

TOP_K_RESULTS= 5
MIN_RESULTS_THRESHOLD = 2
