"""
mock_service.py

Single mock microservice for:
- Auth
- Payment
- User Profile
- Search
- Database
- Connected Vehicle Services

Run:
    python mock_service.py

Server:
    http://localhost:9000
"""

from flask import Flask, request, jsonify
import uuid
import threading
import time
import json
from datetime import datetime


app = Flask(__name__)


# ============================================================================
# COMMON HELPERS
# ============================================================================

def _needs_auth():
    """
    Simple mock authentication.

    Any non-empty:
        Authorization: Bearer <token>

    is considered valid.
    """
    auth = request.headers.get("Authorization", "")

    return (
        not auth.startswith("Bearer ")
        or len(auth) <= len("Bearer ")
    )


def _get_json_body():
    """
    Safely return the request body as a Python dictionary.

    Handles:
        {"pin": "1234"}

    and also:
        '{"pin": "1234"}'

    The second form can occur depending on how RequestsLibrary
    constructs the request.
    """

    body = request.get_json(silent=True)

    # Flask parsed JSON as a string.
    if isinstance(body, str):
        try:
            body = json.loads(body)
        except (TypeError, ValueError):
            return {}

    if not isinstance(body, dict):
        return {}

    return body


# ============================================================================
# AUTH SERVICE
# ============================================================================

@app.route("/api/v1/auth/login", methods=["POST"])
def login():

    body = _get_json_body()

    if not body.get("username") or not body.get("password"):
        return jsonify(
            error="username and password are required"
        ), 400

    if body.get("password") == "wrong":
        return jsonify(
            error="invalid credentials"
        ), 401

    return jsonify(
        token=str(uuid.uuid4()),
        expires_in=3600
    ), 200


@app.route("/api/v1/auth/token/refresh", methods=["POST"])
def refresh_token():

    if _needs_auth():
        return jsonify(
            error="missing or invalid Authorization header"
        ), 401

    body = _get_json_body()

    if not body.get("refresh_token"):
        return jsonify(
            error="refresh_token is required"
        ), 400

    return jsonify(
        token=str(uuid.uuid4()),
        expires_in=3600
    ), 200


# ============================================================================
# PAYMENT SERVICE
# ============================================================================

@app.route("/api/v1/payments/charge", methods=["POST"])
def charge():

    if _needs_auth():
        return jsonify(
            error="missing or invalid Authorization header"
        ), 401

    body = _get_json_body()

    if not body.get("amount") or not body.get("payment_method_id"):
        return jsonify(
            error="amount and payment_method_id are required"
        ), 400

    return jsonify(
        charge_id=str(uuid.uuid4()),
        status="succeeded",
        amount=body["amount"]
    ), 200


@app.route("/api/v1/checkout/session", methods=["POST"])
def checkout_session():

    if _needs_auth():
        return jsonify(
            error="missing or invalid Authorization header"
        ), 401

    body = _get_json_body()

    if not body.get("cart_id"):
        return jsonify(
            error="cart_id is required"
        ), 400

    return jsonify(
        session_id=str(uuid.uuid4()),
        checkout_url="/checkout/" + str(uuid.uuid4())
    ), 200


# ============================================================================
# USER PROFILE SERVICE
# ============================================================================

_KNOWN_USER_IDS = {
    "1",
    "2",
    "3",
    "demo-user"
}


@app.route("/api/v1/users/<user_id>", methods=["PUT"])
def update_profile(user_id):

    if _needs_auth():
        return jsonify(
            error="missing or invalid Authorization header"
        ), 401

    if user_id not in _KNOWN_USER_IDS:
        return jsonify(
            error=f"user {user_id} not found"
        ), 404

    body = _get_json_body()

    if "email" in body and "@" not in body["email"]:
        return jsonify(
            error="invalid email"
        ), 400

    return jsonify(
        id=user_id,
        **body
    ), 200


# ============================================================================
# SEARCH SERVICE
# ============================================================================

@app.route("/api/v1/search", methods=["GET"])
def search():

    q = request.args.get("q")

    if not q:
        return jsonify(
            error="query param 'q' is required"
        ), 400

    page = request.args.get("page", "1")

    if not page.isdigit() or int(page) < 1:
        return jsonify(
            error="page must be a positive integer"
        ), 400

    return jsonify(
        query=q,
        page=int(page),
        results=[
            {
                "id": i,
                "title": f"{q} result {i}"
            }
            for i in range(1, 4)
        ]
    ), 200


# ============================================================================
# DATABASE SERVICE
# ============================================================================

@app.route("/api/v1/health/db", methods=["GET"])
def db_health():

    return jsonify(
        status="ok",
        collation="utf8mb4_unicode_ci"
    ), 200


# ============================================================================
# CONNECTED VEHICLE SERVICES
# ============================================================================

_KNOWN_VINS = {
    "1HGCM82633A004352",
    "5YJ3E1EA7JF000123",
    "JTDKARFP9J3061234"
}

_REMOTE_PIN = "1234"

_KNOWN_SERVICES = {
    "REMOTE_START",
    "WIFI_HOTSPOT",
    "STOLEN_VEHICLE_LOCATOR",
    "REMOTE_DIAGNOSTICS"
}


# ============================================================================
# VEHICLE STATE
# ============================================================================

def _create_initial_vehicle_state():
    """
    Create a fresh vehicle state dictionary.
    """

    return {
        vin: {
            "locked": True,
            "engineOn": False,
            "doorsOpen": False,
            "activeServices": ["REMOTE_START"]
        }
        for vin in _KNOWN_VINS
    }


_vehicle_state = _create_initial_vehicle_state()


def _vehicle_or_404(vin):

    if vin not in _KNOWN_VINS:
        return None

    return _vehicle_state.setdefault(
        vin,
        {
            "locked": True,
            "engineOn": False,
            "doorsOpen": False,
            "activeServices": []
        }
    )


# ============================================================================
# COMMAND STATE
# ============================================================================

_commands = {}

_DISPATCH_DELAY_S = 1.0
_EXECUTE_DELAY_S = 1.5


def _new_command(vin, cmd_type):

    command_id = str(uuid.uuid4())

    command = {
        "commandId": command_id,
        "vin": vin,
        "type": cmd_type,
        "status": "PENDING",
        "requestedAt": datetime.utcnow().isoformat() + "Z",
        "dispatchedAt": None,
        "completedAt": None,
        "failureReason": None
    }

    _commands[command_id] = command

    return command


def _process_command_async(
    command_id,
    vin,
    cmd_type,
    simulate_failure
):
    """
    Simulate asynchronous vehicle communication.

    PENDING
       |
       | 1 second
       v
    DISPATCHED
       |
       | 1.5 seconds
       v
    COMPLETED / FAILED
    """

    # ------------------------------------------------------------------------
    # Dispatch delay
    # ------------------------------------------------------------------------

    time.sleep(_DISPATCH_DELAY_S)

    cmd = _commands.get(command_id)

    if not cmd:
        return

    if cmd["status"] == "CANCELLED":
        return

    cmd["status"] = "DISPATCHED"
    cmd["dispatchedAt"] = (
        datetime.utcnow().isoformat() + "Z"
    )

    # ------------------------------------------------------------------------
    # Vehicle execution delay
    # ------------------------------------------------------------------------

    time.sleep(_EXECUTE_DELAY_S)

    cmd = _commands.get(command_id)

    if not cmd:
        return

    if cmd["status"] == "CANCELLED":
        return

    # ------------------------------------------------------------------------
    # Simulated failure
    # ------------------------------------------------------------------------

    if simulate_failure:

        cmd["status"] = "FAILED"

        cmd["failureReason"] = (
            "Vehicle did not acknowledge the command "
            "(simulated failure)"
        )

    # ------------------------------------------------------------------------
    # Successful execution
    # ------------------------------------------------------------------------

    else:

        cmd["status"] = "COMPLETED"

        state = _vehicle_state.get(vin)

        if state is not None:

            if cmd_type == "ENGINE_START":
                state["engineOn"] = True

            elif cmd_type == "ENGINE_STOP":
                state["engineOn"] = False

    cmd["completedAt"] = (
        datetime.utcnow().isoformat() + "Z"
    )


# ============================================================================
# RESET
# ============================================================================

@app.route("/api/v1/_reset", methods=["POST"])
def reset_state():

    global _vehicle_state
    global _commands

    _vehicle_state = _create_initial_vehicle_state()
    _commands = {}

    return jsonify(
        status="ok",
        reset=list(_KNOWN_VINS)
    ), 200


# ============================================================================
# REMOTE START
# ============================================================================

@app.route(
    "/api/v1/vehicle/<vin>/remote/start",
    methods=["POST"]
)
def remote_start(vin):
    """
    Remote engine start.

    Expected by current Robot tests:

        Valid request       -> 200
        Missing PIN         -> 400
        Missing auth        -> 401
        Invalid PIN         -> 403
        Unknown VIN         -> 404

    Internally the command remains asynchronous.
    """

    # ------------------------------------------------------------------------
    # Authentication
    # ------------------------------------------------------------------------

    if _needs_auth():

        return jsonify(
            error="missing or invalid Authorization header"
        ), 401

    # ------------------------------------------------------------------------
    # Vehicle validation
    # ------------------------------------------------------------------------

    state = _vehicle_or_404(vin)

    if state is None:

        return jsonify(
            error=f"vehicle {vin} not found"
        ), 404

    # ------------------------------------------------------------------------
    # Request body
    # ------------------------------------------------------------------------

    body = _get_json_body()

    pin = body.get("pin")

    # ------------------------------------------------------------------------
    # Missing PIN
    # ------------------------------------------------------------------------

    if not pin:

        return jsonify(
            error="pin is required"
        ), 400

    # ------------------------------------------------------------------------
    # Invalid PIN
    # ------------------------------------------------------------------------

    if str(pin) != _REMOTE_PIN:

        return jsonify(
            error="invalid PIN"
        ), 403

    # ------------------------------------------------------------------------
    # Remote Start service
    # ------------------------------------------------------------------------

    if "REMOTE_START" not in state["activeServices"]:

        return jsonify(
            error="Remote Start service is not active on this vehicle"
        ), 403

    # ------------------------------------------------------------------------
    # Engine state
    # ------------------------------------------------------------------------

    if state["engineOn"]:

        return jsonify(
            error="engine is already running"
        ), 409

    # ------------------------------------------------------------------------
    # Door state
    # ------------------------------------------------------------------------

    if state["doorsOpen"]:

        return jsonify(
            error="cannot remote start while a door is open"
        ), 409

    # ------------------------------------------------------------------------
    # Create command
    # ------------------------------------------------------------------------

    cmd = _new_command(
        vin,
        "ENGINE_START"
    )

    # ------------------------------------------------------------------------
    # Background processing
    # ------------------------------------------------------------------------

    threading.Thread(
        target=_process_command_async,
        args=(
            cmd["commandId"],
            vin,
            "ENGINE_START",
            bool(body.get("simulateFailure"))
        ),
        daemon=True
    ).start()

    # ------------------------------------------------------------------------
    # Return HTTP 200 because existing Robot test expects 200.
    # ------------------------------------------------------------------------

    return jsonify(
        commandId=cmd["commandId"],
        vin=vin,
        type="ENGINE_START",
        status="PENDING",
        requestedAt=cmd["requestedAt"]
    ), 200


# ============================================================================
# REMOTE STOP
# ============================================================================

@app.route(
    "/api/v1/vehicle/<vin>/remote/stop",
    methods=["POST"]
)
def remote_stop(vin):
    """
    Remote engine stop.

    Expected by current Robot tests:

        Valid request       -> 200
        Missing auth        -> 401
        Unknown VIN         -> 404

    IMPORTANT:
    We intentionally do not require engineOn=True because
    the generated Robot test sends a stop request against
    the initially stopped vehicle.
    """

    # ------------------------------------------------------------------------
    # Authentication
    # ------------------------------------------------------------------------

    if _needs_auth():

        return jsonify(
            error="missing or invalid Authorization header"
        ), 401

    # ------------------------------------------------------------------------
    # Vehicle validation
    # ------------------------------------------------------------------------

    state = _vehicle_or_404(vin)

    if state is None:

        return jsonify(
            error=f"vehicle {vin} not found"
        ), 404

    # ------------------------------------------------------------------------
    # Parse body
    # ------------------------------------------------------------------------

    body = _get_json_body()

    # ------------------------------------------------------------------------
    # IMPORTANT:
    #
    # Do NOT do:
    #
    # if not state["engineOn"]:
    #     return jsonify(error="engine is not running"), 409
    #
    # because the Robot test expects 200 while engineOn=False.
    # ------------------------------------------------------------------------

    cmd = _new_command(
        vin,
        "ENGINE_STOP"
    )

    threading.Thread(
        target=_process_command_async,
        args=(
            cmd["commandId"],
            vin,
            "ENGINE_STOP",
            bool(body.get("simulateFailure"))
        ),
        daemon=True
    ).start()

    # ------------------------------------------------------------------------
    # Return HTTP 200 because existing Robot test expects 200.
    # ------------------------------------------------------------------------

    return jsonify(
        commandId=cmd["commandId"],
        vin=vin,
        type="ENGINE_STOP",
        status="PENDING",
        requestedAt=cmd["requestedAt"]
    ), 200


# ============================================================================
# GET COMMAND STATUS
# ============================================================================

@app.route(
    "/api/v1/vehicle/<vin>/remote/commands/<command_id>",
    methods=["GET"]
)
def get_command_status(vin, command_id):
    if _needs_auth():
        return jsonify(
            error="missing or invalid Authorization header"
        ), 401
    cmd = _commands.get(command_id)

    if not cmd or cmd["vin"] != vin:

        return jsonify(
            error=(
                f"command {command_id} not found "
                f"for vehicle {vin}"
            )
        ), 404

    return jsonify(**cmd), 200


# ============================================================================
# LIST COMMANDS
# ============================================================================

@app.route(
    "/api/v1/vehicle/<vin>/remote/commands",
    methods=["GET"]
)
def list_commands(vin):

    if _needs_auth():

        return jsonify(
            error="missing or invalid Authorization header"
        ), 401

    if vin not in _KNOWN_VINS:

        return jsonify(
            error=f"vehicle {vin} not found"
        ), 404

    cmds = [
        command
        for command in _commands.values()
        if command["vin"] == vin
    ]

    return jsonify(
        vin=vin,
        commands=cmds,
        total=len(cmds)
    ), 200


# ============================================================================
# CANCEL COMMAND
# ============================================================================

@app.route(
    "/api/v1/vehicle/<vin>/remote/commands/<command_id>",
    methods=["DELETE"]
)
def cancel_command(vin, command_id):

    if _needs_auth():

        return jsonify(
            error="missing or invalid Authorization header"
        ), 401

    cmd = _commands.get(command_id)

    if not cmd or cmd["vin"] != vin:

        return jsonify(
            error=(
                f"command {command_id} not found "
                f"for vehicle {vin}"
            )
        ), 404

    if cmd["status"] != "PENDING":

        return jsonify(
            error=(
                f"cannot cancel a command "
                f"in status {cmd['status']}"
            )
        ), 409

    cmd["status"] = "CANCELLED"

    return jsonify(
        commandId=command_id,
        status="CANCELLED"
    ), 200


# ============================================================================
# REMOTE LOCK
# ============================================================================

@app.route(
    "/api/v1/vehicle/<vin>/remote/lock",
    methods=["POST"]
)
def remote_lock(vin):

    if _needs_auth():

        return jsonify(
            error="missing or invalid Authorization header"
        ), 401

    state = _vehicle_or_404(vin)

    if state is None:

        return jsonify(
            error=f"vehicle {vin} not found"
        ), 404

    if state["doorsOpen"]:

        return jsonify(
            error="cannot lock while a door is open"
        ), 409

    state["locked"] = True

    return jsonify(
        commandId=str(uuid.uuid4()),
        status="LOCKED"
    ), 200


# ============================================================================
# REMOTE UNLOCK
# ============================================================================

@app.route(
    "/api/v1/vehicle/<vin>/remote/unlock",
    methods=["POST"]
)
def remote_unlock(vin):

    if _needs_auth():

        return jsonify(
            error="missing or invalid Authorization header"
        ), 401

    state = _vehicle_or_404(vin)

    if state is None:

        return jsonify(
            error=f"vehicle {vin} not found"
        ), 404

    body = _get_json_body()

    pin = body.get("pin")

    if not pin:

        return jsonify(
            error="pin is required"
        ), 400

    if str(pin) != _REMOTE_PIN:

        return jsonify(
            error="invalid PIN"
        ), 403

    state["locked"] = False

    return jsonify(
        commandId=str(uuid.uuid4()),
        status="UNLOCKED"
    ), 200


# ============================================================================
# REMOTE LOCATE
# ============================================================================

@app.route(
    "/api/v1/vehicle/<vin>/remote/locate",
    methods=["POST"]
)
def remote_locate(vin):

    if _needs_auth():

        return jsonify(
            error="missing or invalid Authorization header"
        ), 401

    state = _vehicle_or_404(vin)

    if state is None:

        return jsonify(
            error=f"vehicle {vin} not found"
        ), 404

    body = _get_json_body()

    mode = body.get(
        "mode",
        "lights_and_horn"
    )

    if mode not in (
        "lights",
        "horn",
        "lights_and_horn"
    ):

        return jsonify(
            error=(
                "mode must be one of: "
                "lights, horn, lights_and_horn"
            )
        ), 400

    return jsonify(
        commandId=str(uuid.uuid4()),
        status="TRIGGERED",
        mode=mode
    ), 200


# ============================================================================
# VEHICLE STATUS
# ============================================================================

@app.route(
    "/api/v1/vehicle/<vin>/status",
    methods=["GET"]
)
def vehicle_status(vin):

    if _needs_auth():

        return jsonify(
            error="missing or invalid Authorization header"
        ), 401

    state = _vehicle_or_404(vin)

    if state is None:

        return jsonify(
            error=f"vehicle {vin} not found"
        ), 404

    return jsonify(
        vin=vin,
        locked=state["locked"],
        engineOn=state["engineOn"],
        doorsOpen=state["doorsOpen"],
        activeServices=state["activeServices"],
        fuelLevelPct=72,
        odometerMiles=18422
    ), 200


# ============================================================================
# SERVICE ACTIVATE
# ============================================================================

@app.route(
    "/api/v1/services/<vin>/activate",
    methods=["POST"]
)
def activate_service(vin):

    if _needs_auth():

        return jsonify(
            error="missing or invalid Authorization header"
        ), 401

    state = _vehicle_or_404(vin)

    if state is None:

        return jsonify(
            error=f"vehicle {vin} not found"
        ), 404

    body = _get_json_body()

    service_code = body.get("serviceCode")

    if not service_code:

        return jsonify(
            error="serviceCode is required"
        ), 400

    if service_code not in _KNOWN_SERVICES:

        return jsonify(
            error=f"unknown serviceCode '{service_code}'"
        ), 400

    if service_code in state["activeServices"]:

        return jsonify(
            error=(
                f"{service_code} is already active "
                f"on this vehicle"
            )
        ), 409

    state["activeServices"].append(service_code)

    return jsonify(
        activationId=str(uuid.uuid4()),
        serviceCode=service_code,
        status="ACTIVE"
    ), 200


# ============================================================================
# SERVICE DEACTIVATE
# ============================================================================

@app.route(
    "/api/v1/services/<vin>/deactivate",
    methods=["POST"]
)
def deactivate_service(vin):

    if _needs_auth():

        return jsonify(
            error="missing or invalid Authorization header"
        ), 401

    state = _vehicle_or_404(vin)

    if state is None:

        return jsonify(
            error=f"vehicle {vin} not found"
        ), 404

    body = _get_json_body()

    service_code = body.get("serviceCode")

    if not service_code:

        return jsonify(
            error="serviceCode is required"
        ), 400

    if service_code not in state["activeServices"]:

        return jsonify(
            error=(
                f"{service_code} is not active "
                f"on this vehicle"
            )
        ), 409

    state["activeServices"].remove(service_code)

    return jsonify(
        serviceCode=service_code,
        status="INACTIVE"
    ), 200


# ============================================================================
# HEALTH
# ============================================================================

@app.route("/health", methods=["GET"])
def health():

    return jsonify(
        status="ok",
        service="mock-microservice"
    ), 200


# ============================================================================
# START SERVER
# ============================================================================

if __name__ == "__main__":

    print("=" * 70)
    print("Mock microservice running on http://localhost:9000")
    print("=" * 70)

    print("")
    print("General APIs:")
    print("  POST /api/v1/auth/login")
    print("  POST /api/v1/auth/token/refresh")
    print("  POST /api/v1/payments/charge")
    print("  POST /api/v1/checkout/session")
    print("  PUT  /api/v1/users/<id>")
    print("  GET  /api/v1/search")
    print("  GET  /api/v1/health/db")

    print("")
    print("Connected Vehicle APIs:")
    print("  POST /api/v1/vehicle/<vin>/remote/start")
    print("  POST /api/v1/vehicle/<vin>/remote/stop")
    print("  GET  /api/v1/vehicle/<vin>/remote/commands")
    print("  GET  /api/v1/vehicle/<vin>/remote/commands/<command_id>")
    print("  DELETE /api/v1/vehicle/<vin>/remote/commands/<command_id>")
    print("  POST /api/v1/vehicle/<vin>/remote/lock")
    print("  POST /api/v1/vehicle/<vin>/remote/unlock")
    print("  POST /api/v1/vehicle/<vin>/remote/locate")
    print("  GET  /api/v1/vehicle/<vin>/status")

    print("")
    print("Service APIs:")
    print("  POST /api/v1/services/<vin>/activate")
    print("  POST /api/v1/services/<vin>/deactivate")

    print("")
    print("Test utilities:")
    print("  POST /api/v1/_reset")
    print("  GET  /health")
    print("")

    app.run(
        host="0.0.0.0",
        port=9000
    )
