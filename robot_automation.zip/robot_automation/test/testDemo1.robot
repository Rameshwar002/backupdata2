*** Settings ***
Documentation    To validate the login from 
Library    SeleniumLibrary
Test Teardown    Close Browser
#Resource

*** Test Cases ***
Validate UnSuccessful Login
    [Tags]    Regression
    Open Browser with the Mortgage payments url
    Fill the login Form
    wait until it checks and display error message
    verify error message is correct

*** Keywords ***
Open Browser with the Mortgage payments url
    Create Webdriver    Chrome
    Go To    https://rahulshettyacademy.com/loginpagePractise/
    
Fill the login Form
    Input Text    id:username    rameshwara
    Input Password    id:password    12345
    Click Button    signInBtn

wait until it checks and display error message
    Wait Until Element Is Visible    css:.alert-danger
    
verify error message is correct
   ${result}=  Get Text    css:.alert-danger
   Should Be Equal As Strings    ${result}     Incorrect username/password.


*** Test Cases ***
Validate Successful Login
    [Tags]    Regression
    Open Browser with the Mortgage payments urls
    Fill the login Forms

*** Keywords ***
Open Browser with the Mortgage payments urls
    Create Webdriver    Chrome
    Go To    https://rahulshettyacademy.com/loginpagePractise/

Fill the login Forms
    Input Text    id:username    rahulshettyacademy
    Input Password    id:password    Learning@830$3mK2
    Click Button    signInBtn

