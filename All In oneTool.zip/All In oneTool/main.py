import streamlit as st


from tools.rag_pipline.ui.chat_ui import render_chat_ui
from tools.rag_pipline.ui.upload_ui import render_upload_ui
from tools.testTrillFileGenerater import render_bdd_generator_ui
from tools.testcaseGenerate import render_test_case_generator
from tools.HLD_LLD_Generater import render_test1
from tools.unit_testcse_generator.app import run_app

st.set_page_config(page_title="Tester Bot", layout="wide")

st.sidebar.title("🧰 Tester Bot")

# Tool registry (router)
TOOLS = {
    "scenario base Test Case Generator": render_test_case_generator,
    "HLD LLD Generator": render_test1,
    "Test Trill": render_bdd_generator_ui,
    "Rag DataUploader" : render_upload_ui,
    "Rag ChatBot": render_chat_ui,
    "Unit Testcase Generator (Rule Base)": run_app
}

selected_tool = st.sidebar.radio(
    "Select Tool",
    list(TOOLS.keys())
)

TOOLS[selected_tool]()