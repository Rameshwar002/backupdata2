junit_prompt = """
You are a Senior Java developer.

Generate unit test cases java file.

Class Type: {class_type}
Class Name: {class_name}

Rules:
- Use Mockito if dependencies exist
- Follow AAA pattern
- Cover success, failure, edge cases
- Use @ExtendWith(MockitoExtension.class) for all class
- Achieve 90%+ coverage


Java Source:
{java_code}



Give only java code do not include any documentation. 
"""