import streamlit as st
import time
import pandas as pd

from tools.unit_testcse_generator.core.classClassifier import classify
from tools.unit_testcse_generator.core.fileScanner import scan_java_files
from tools.unit_testcse_generator.core.testAggregator import create_test_bundle
from tools.unit_testcse_generator.core.testMatcher import find_missing_tests
from tools.unit_testcse_generator.core.zipHandler import extract_zip
from tools.unit_testcse_generator.llm.unitTestCaseGenerator import generate_test
from tools.unit_testcse_generator.utils.fileHandlerUtils import sanitize_test_code
from tools.unit_testcse_generator.utils.pathUtils import build_test_path


def run_app():
    st.set_page_config(page_title="Unit Test Generator", layout="wide")

    st.title("🧪Unit Test Generator")
    st.caption("Batch • Status Tracking • Audit Ready")

    if "table" not in st.session_state:
        st.session_state.table = None

    if "test_zip" not in st.session_state:
        st.session_state.test_zip = None

    if "generated_tests" not in st.session_state:
        st.session_state.generated_tests = []


    zip_file = st.file_uploader("Upload Microservices ZIP", type=["zip"])
    if not zip_file:
        return

    root = extract_zip(zip_file)
    main_files, test_files = scan_java_files(root)
    missing = find_missing_tests(main_files, test_files)

    if not missing:
        st.success("🎉 All files already have unit tests")
        return

    st.subheader("🚨 Application Files Without Unit Tests")

    if st.session_state.table is None:
        st.session_state.table = pd.DataFrame([
            {
                "File Name": f"{m['class']}.java",
                "File Path": m["source"].replace(root, ""),
                "Status": "⏳ Pending",
                "Remarks": ""
            }
            for m in missing
        ])

    table_placeholder = st.empty()
    table_placeholder.dataframe(
        st.session_state.table,
        use_container_width=True
    )


    if st.button("🚀 Generate Test Cases (Auto)"):
        progress = st.progress(0)
        total = len(missing)

        st.session_state.generated_tests = []

        for i, item in enumerate(missing):
            cls = item["class"]
            src = item["source"]

            # Update status → In Progress
            st.session_state.table.loc[
                st.session_state.table["File Name"] == f"{cls}.java",
                "Status"
            ] = "⚙ In Progress"

            table_placeholder.dataframe(
                st.session_state.table,
                use_container_width=True
            )

            try:
                with open(src, "r", encoding="utf-8") as f:
                    java_code = f.read()

                class_type = classify(java_code)

                raw_test_code = generate_test(
                    java_code=java_code,
                    class_name=cls,
                    class_type=class_type
                )

                test_code = sanitize_test_code(
                    raw_code=raw_test_code,
                    class_name=cls
                )

                test_path = build_test_path(
                    root,
                    item["package"],
                    cls
                )

                with open(test_path, "w", encoding="utf-8") as f:
                    f.write(test_code[0])

                st.session_state.generated_tests.append({
                    "path": test_path,
                    "content": test_code
                })

                # Update status → Done
                st.session_state.table.loc[
                    st.session_state.table["File Name"] == f"{cls}.java",
                    ["Status", "Remarks"]
                ] = ["✅ Done", "Test generated successfully"]

            except Exception as e:
                # Update status → Failed
                st.session_state.table.loc[
                    st.session_state.table["File Name"] == f"{cls}.java",
                    ["Status", "Remarks"]
                ] = ["❌ Failed", str(e)]

            progress.progress((i + 1) / total)
            table_placeholder.dataframe(
                st.session_state.table,
                use_container_width=True
            )

            time.sleep(0.2)

        if st.session_state.generated_tests:
            st.session_state.test_zip = create_test_bundle(
                root,
                st.session_state.generated_tests
            )

        st.success("✅ Batch generation completed")

    if st.session_state.test_zip is not None:
        st.download_button(
            label="⬇ Download All Unit Tests",
            data=st.session_state.test_zip,
            file_name="all-unit-tests.zip",
            mime="application/zip"
        )

if __name__ == "__main__":
    run_app()