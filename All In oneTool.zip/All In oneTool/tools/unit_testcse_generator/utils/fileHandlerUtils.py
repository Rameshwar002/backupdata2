import  re

def sanitize_test_code(raw_code:str ,class_name: str) :
    raw_code =re.sub(r"```java","", raw_code, flags=re.IGNORECASE)
    raw_code =re.sub(r"```","", raw_code)

    noise_patterns = [
        r"^Sure.*?\n",
        r"^Here is.*?\n",
        r"Hope this helps.*",
        r"Let me know.*",
    ]

    for p in noise_patterns:
        raw_code = re.sub(p, "", raw_code, flags=re.IGNORECASE | re.DOTALL)
    try:
        raw_code = raw_code[raw_code.index("'''java")+1:raw_code.rindex("'''")]
    except Exception as e:
        try:
            raw_code = raw_code[raw_code.index("'''") + 1:raw_code.rindex("'''")]
        except Exception as e:
            pass

    c_name = f"{class_name}Test.java"
    print("class: ",c_name)
    return str(raw_code) , c_name
