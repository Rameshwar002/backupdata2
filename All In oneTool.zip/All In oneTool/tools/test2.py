import streamlit as st

def render_test2():
    st.title("Tester Bot")
    st.info("TODO connection with test trill so we can directly run the file from here it self ")