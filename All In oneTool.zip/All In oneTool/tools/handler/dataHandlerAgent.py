import streamlit as st
import ollama


def datahandler(raw_output, puml_content):
    prompt = f"""
  PlantUML content:
  {puml_content}
  Row output:
  {raw_output}
    
    
  """

    with st.spinner("🤖 Generating test cases using Llama 3.2..."):
        response = ollama.chat(
            model="llama3.2",
            messages=[{"role": "user", "content": prompt}]
        )

    raw2_output = response["message"]["content"]
