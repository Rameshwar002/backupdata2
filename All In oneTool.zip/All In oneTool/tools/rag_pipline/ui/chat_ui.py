import streamlit as st

from tools.rag_pipline.config.llm_config import assistent
from tools.rag_pipline.core.retriever import retrieve
from tools.rag_pipline.core.vectordb import get_indexed_file_count


def format_answer(text: str) -> str:
    """
    Convert chunk text into readable markdown
    """
    lines = [l.strip() for l in text.split("\n") if l.strip()]
    if not lines:
        return ""

    heading = lines[0]
    body = lines[1:]

    md = f"**{heading}**\n\n"
    for line in body:
        md += f"- {line}\n"

    return md


def render_chat_ui():
    col1, col2 = st.columns([3, 1])

    # RIGHT SIDE – Stats
    with col2:
        st.markdown("### 📊 Knowledge Stats")
        st.metric(
            label="📁 Indexed Files",
            value=get_indexed_file_count()
        )

    # LEFT SIDE – Chat
    with col1:
        st.header("💬 Knowledge ChatBot")

        query = st.text_input("Ask your question")

        if st.button("Search") and query:

            results = retrieve(query)
            llmresponce = assistent(query, results)



            if not results:
                st.warning("No relevant information found")
                return

            st.markdown(llmresponce)
            st.markdown("---")
