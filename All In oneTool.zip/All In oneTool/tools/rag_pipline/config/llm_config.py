import ollama
import streamlit as st


def assistent(question, puml_content):
    prompt = f"""
You are an expert assistant. Your task is to create a **clear and human-readable answer** to the user's question 
strictly using the raw data provided. Do not add any information that is not in the raw data.

Question: {question}
Raw Data: {puml_content}

Instructions:
- Read the raw data carefully.
- Provide a concise and accurate answer to the question.
- Make the answer easy to understand for humans.
- If the data does not provide enough information, clearly say: 'Insufficient data to answer the question.'
- No extra text
- No markdown

Answer:
"""

    with st.spinner("🤖 answer..."):
        response = ollama.chat(
            model="llama3.2",
            messages=[{"role": "user", "content": prompt}]
        )

    raw_output = response["message"]["content"]
    print(raw_output)
    return raw_output