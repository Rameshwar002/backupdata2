EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L12-v2"
CHUNK_SIZE = 1000
CHUNK_OVERLAP = 200
VECTOR_DB_PATH = "data/vectordb"
RAW_DATA_PATH = "data/raw"
TOP_K = 2